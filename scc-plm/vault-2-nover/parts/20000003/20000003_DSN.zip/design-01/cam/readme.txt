*************************************************************
SWIFT CONSTRUCTION COMPANY
PCB PN: 20000002
REV: 01
NAME: PCB, AIRCRAFT WIRLESS
MATL: 1-SIDE Glass Epoxy

CONTACT: Barcoe Jenks, bjenks@scc.com
*************************************************************

design.drl           : text drill file
design-Component.pho : component outline
design-Copper.pho    : copper (bottom) layer
design-Edges_Pcb.pho : mechanical pcb outline
design-SilkS-Cmp.pho : component (top) silk screen
readme.txt           : this file

Size: 3.20" x 2"

*************************************************************
