2011-02-28

Graphic file source, attribution, and applicable license.

Amplitude_modulation_detection.png
-----------------------------------
Website: Wikipedia.  File:Amplitude modulation detection.png.  http://commons.wikimedia.org/wiki/File:Amplitude_modulation_detection.png (accessed 2011-02-28).

Licensing: This media file is in the public domain in the United States. Adapted from Harry J. Marx, Adrian Van Muffling (1922) Radio Reception: A simple and complete explanation of the principles of radio telephony, G.P. Putnam's sons, New York, p.43, fig.27.

biplane.jpg
-----------------------------------
Website: FunDraw.com. Biplane � Line Drawing. http://www.fundraw.com/clipart/clip-art/3150/Biplane---
Line-Drawing/ (accessed 2010-10-19).

Licensing: Public domain artwork.

###

