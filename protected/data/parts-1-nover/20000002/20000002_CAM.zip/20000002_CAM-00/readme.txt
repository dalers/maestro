*************************************************************
SWIFT CONSTRUCTION COMPANY
PN: 20000002
REV: 0
NAME: PCB, AIRCRAFT WIRLESS
MATL: 1-SIDE Glass Epoxy

CONTACT: Barcoe Jenks, bjenks@scc.com
*************************************************************

20000002-TOP.GBR : top copper
20000002-BOT.GBR : bottom copper
20000002-TS.GBR  : top silkscreen
20000002-TR.GBR  : top solder resist
20000002-BR.GBR  : bottom resist
20000002-TM.GBR  : top mask (board extents)
20000002-BM.GBR  : bottom mask (board extents)
20000002-DRL.GBR : drill file
readme.txt       : this file

Size: 109.8728 x 90.1802 mm
Total Drills: 146, Total Pads: 584, Total Traces 20492

*************************************************************
These CAM files are not consistent with 20000003_DSN-01.zip
They were created by Dinesh Gajjar and provided for free
download as documentation for a crystal radio design(1).

These files will be replaced at a future date with an original
pcb design based on the 20000003_DSN design.

(1) Website: Electronic hobby projects by Nina Gaffar. A Simple
Crystal Radio Kit. http://www.foxdelta.com/nina/crystal.html
(accessed 2010-10-20). 
 
(C) 2010 by Dale R. Scott. This work is licensed under a Creative 
Commons Attribution 3.0 Unported License. 
http://creativecommons.org/licenses/by/3.0/ 

*************************************************************
###
