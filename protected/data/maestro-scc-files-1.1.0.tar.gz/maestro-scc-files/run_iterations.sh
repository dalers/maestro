#!/bin/sh
#
# Run through iterations in fast motion
# - cd into top dir of extracted SCC demo data (maestro)
#
# - assumes following fileshare directory structure exists
#   /usr/home/samba/maestro                 - root of fileshare
#   /usr/home/samba/maestro/remotefs/       - simulated remote fs (optional)
#   /usr/home/samba/maestro/vault           - document vault
#   /usr/home/samba/maestro/vault.backup    - document backups (optional)
#
#  - assumes SCC demo data tar file extracted to current directory
#    > tar -xzf maestro-scc-files.tar.gz
#
#    maestro
#    |-- pv-1.mdb                      P&V(TM) mdb
#    |-- pv-2.mdb
#    |-- pv-3.mdb
#    |-- pv-4.mdb
#    |-- csv-1                         mdb-export from P&V(TM) mdb
#    |   |-- issue.csv
#    |   |-- person.cvs
#    |   |-- ...
#    |   `-- stock_serial.csv
#    |-- csv-2
#    |   `-- ...
#    |-- csv-3
#    |   `-- ...
#    |-- csv-4
#    |   `-- ...
#    |-- vault-1                       file vault
#    |   |-- 20000001
#    |   |   |-- 20000001_WI-00.odt
#    |   |   |-- 20000001_WI-00.pdf
#    |   |   `-- 20000001_WI-00_graphics.odg
#    |   |-- 20000002
#    |   |-- 20000003
#    |   |-- ...
#    |   `-- 90000013
#    |-- vault-2
#    |   `-- ...
#    |-- vault-3
#    |   `...
#    `-- vault-4
#        `...

# -----------------
# startup
# -----------------

# remove any output files in current directory
echo "configuring system..."
rm ./run_iterations_rsync*.log

# remove any existing files
rm /home/samba/maestro/*
# simulated remote fs
rm -r /home/samba/maestro/remotefs/*
# file vault
rm -r /home/samba/maestro/vault/*
#rm -r /home/samba/maestro/vault.backup/*
# current and previous csv
rm /home/samba/maestro/csv/*
rm /home/samba/maestro/csv.old/*

# ensure required fileshare owner/mod (web server must have read/write permission)
chown -R www:www /home/samba/maestro/

# copy spreadsheets to maestro share
cp ./excel/*.xlsx /home/samba/maestro/

# set owner files (cosmetic for creation of maestro-scc-files.tar.gz)
chown -R maestro:maestro *

# set access/modification dates for each iteration
touch -t 200412231300 csv-1/*
find ./vault-1 -exec touch -t 200412231300 {} \;

touch -t 200412231300 csv-2/*
find ./vault-2 -exec touch -t 200501101300 {} \;

touch -t 200412231300 csv-3/*
find ./vault-3 -exec touch -t 200502241300 {} \;

touch -t 200412231300 csv-4/*
find ./vault-4 -exec touch -t 200503151300 {} \;

touch -t 200412231300 excel/*

echo ""

# -----------------
echo "Iteration 1..."
# -----------------

# copy Parts&Vendors(TM) database
# archive mode preserves file times
echo "restore iteration 1 mdb"
cp -a ./pv-1.mdb /home/samba/maestro/pv.mdb

echo "restore iteration 1 csv"
cp -a ./csv-1/* /home/samba/maestro/csv
# re-generate pv csv from mdb
#./export_current_to_csv.sh

echo "restore iteration 1 vault"
cp -a ./vault-1/* /home/samba/maestro/remotefs

echo "rsync remote fs iteration 1 to maestro vault"
rsync -a --itemize-changes --backup --suffix=-`date +%FT%T` --log-file="./run_iterations_rsync-1.log" /usr/home/samba/maestro/remotefs/ /usr/home/samba/maestro/vault >> ./run_iterations_rsync.log

echo "PUT CALL TO MAESTRO LOAD-CURRENT HERE"
echo ""
 
# -----------------
echo "Iteration 2..."
# -----------------

# copy Parts&Vendors(TM) database
# archive mode preserves file times
echo "restore iteration 2 mdb"
cp -a ./pv-2.mdb /home/samba/maestro/pv.mdb

echo "restore iteration 2 csv"
cp -a ./csv-2/* /home/samba/maestro/csv
# re-generate pv csv from mdb
#./export_current_to_csv.sh

echo "restore iteration 2 vault"
cp -a ./vault-2/* /home/samba/maestro/remotefs

echo "rsync remote fs iteration 2 to maestro vault"
echo ""; echo "Iteration 2" >> run_iterations_rsync.log
rsync -a --itemize-changes --backup --suffix=-`date +%FT%T` --log-file="./run_iterations_rsync-2.log" /usr/home/samba/maestro/remotefs/ /usr/home/samba/maestro/vault >> ./run_iterations_rsync.log

echo "PUT CALL TO MAESTRO LOAD-CURRENT HERE"
echo ""
 
# -----------------
echo "Iteration 3..."
# -----------------

# copy Parts&Vendors(TM) database
# archive mode preserves file times
echo "restore iteration 3 mdb"
cp -a ./pv-3.mdb /home/samba/maestro/pv.mdb

echo "restore iteration 3 csv"
cp -a ./csv-3/* /home/samba/maestro/csv
# re-generate pv csv from mdb
#./export_current_to_csv.sh

echo "restore iteration 3 vault"
cp -a -p ./vault-3/* /home/samba/maestro/remotefs

echo "rsync remote fs iteration 3 to maestro vault"
echo ""; echo "Iteration 3" >> run_iterations_rsync.log
rsync -a --itemize-changes --backup --suffix=-`date +%FT%T` --log-file="./run_iterations_rsync-3.log" /usr/home/samba/maestro/remotefs/ /usr/home/samba/maestro/vault >> ./run_iterations_rsync.log

echo "PUT CALL TO MAESTRO LOAD-CURRENT HERE"
echo ""
 
# -----------------
echo "Iteration 4..."
# -----------------

# copy Parts&Vendors(TM) database
# archive mode preserves file times
echo "restore iteration 4 mdb"
cp -a ./pv-4.mdb /home/samba/maestro/pv.mdb

echo "restore iteration 4 csv"
cp -a ./csv-4/* /home/samba/maestro/csv
# re-generate pv csv from mdb
#./export_current_to_csv.sh

echo "restore iteration 4 vault"
cp -a -p ./vault-4/* /home/samba/maestro/remotefs

echo "rsync remote fs iteration 4 to maestro vault"
echo ""; echo "Iteration 4" >> run_iterations_rsync.log
rsync -a --itemize-changes --backup --suffix=-`date +%FT%T` --log-file="./run_iterations_rsync-4.log" /usr/home/samba/maestro/remotefs/ /usr/home/samba/maestro/vault >> ./run_iterations_rsync.log

echo "PUT CALL TO MAESTRO LOAD-CURRENT HERE"
echo ""

# -----------------
# cleanup
# -----------------

echo "Done!"
echo ""
