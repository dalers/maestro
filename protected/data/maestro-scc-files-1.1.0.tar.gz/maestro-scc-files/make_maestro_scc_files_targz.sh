#!/bin/sh
#
# Create maestro-scc-files-xxx.tar.gz from directory structure
# - execute from top level of file directory
#
# Iteration:
# 1  Prototype                   2004-12-23
# 2  PCB Revision                2005-01-10
# 3  Product Release             2005-02-24
# 4  Manufacturing Improvements  2005-03-15
#
# Refer to the Maestro project wiki for more information.
#

# set owner (cosmetic)
chown -R maestro:maestro *

# set access/modification dates for each iteration
touch -t 200412231300 csv-1/*
find ./vault-1 -exec touch -t 200412231300 {} \;

touch -t 200412231300 csv-2/*
find ./vault-2 -exec touch -t 200501101300 {} \;

touch -t 200412231300 csv-3/*
find ./vault-3 -exec touch -t 200502241300 {} \;

touch -t 200412231300 csv-4/*
find ./vault-4 -exec touch -t 200503151300 {} \;

touch -t 200412231300 excel/*

touch -t 200412231300 pv-1.mdb
touch -t 200501101300 pv-2.mdb
touch -t 200502241300 pv-3.mdb
touch -t 200503151300 pv-4.mdb

# create tar.gz
cd ..
tar -czf maestro-scc-files-x.x.x.tar.gz maestro-scc-files
