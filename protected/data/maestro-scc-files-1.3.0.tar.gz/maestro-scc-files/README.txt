Files here are used by Maestro - the SME business management system.

Maestro integrates and controls current data from the following: 

* Person spreadsheet           Maestro users and related information
* Parts&Vendors(TM)*           Part numbers, part lists, and part sources
* Project spreadsheet          Projects and related information
* Issue spreadsheet            Issues and related information
* Serial number spreadsheet    Serial numbers for serialized material
* Stock location spreadsheet   Material stocking locations
* File share documents         Add hoc documents 

Maestro automatically imports current data from the above sources for
controlled management (typically automatically every night).

For more information, consult your Maestro system administrator.


Accessing documents from within Parts&Vendors
---------------------------------------------

1. Map a drive letter (e.g. "X") to the Maestro smb ("Windows") file
share on the Maestro server using either the DNS hostname or IP address
of the Maestro server (e.g. \\firefly.scc.local\maestro or
\\192.168.10.130\maestro). The root of the mapped drive must contain
the vault\ directory. 

2. Configure Parts&Vendors to substitute the mapped drive letter in the 
file path for documents in the Part Master Files/URLs tab (P&V > Edit > 
Options > Viewers/Path, select "Use Network Path or Drive", select 
"Substitute Drive Letter Only", and enter the mapped drive letter). 


Trademarks
---------------------------------------------
* Parts&Vendors(TM) is an unregistered trademark of Trilogy Design.
(http://www.trilogydesign.com).

###
